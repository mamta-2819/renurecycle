<style>
    .environment-project ul li{
        margin:0px!important;
    }

    .environment-project ul  section li::before{
        content: "\f00c";
    font-family: FontAwesome;
    margin-right: 10px;
    font-size: 14px;
    color: #9cc900;
    }

</style>

<?php
include "include/header.php";
?>


<div class="environment-subheader">
<span class="subheader-transparent"></span>
<div class="container">
<div class="row">
<div class="col-md-12">
<h1>E-waste</h1>
</div>
<div class="col-md-12">
<ul class="environment-breadcrumb">
<li><a href="index.php">Home</a></li>
<li class="active">E-waste</li>
</ul>
</div>
</div>
</div>
</div>


<div class="environment-main-content">

<div class="environment-main-section environment-aboutus-textfull">
<div class="container">

<div class="row">
<div class="col-md-12">
<div class="environment-section-title"><h2>E- <span>waste</span></h2></div>
<div class="environment-event-organizer">

<p>E-waste is a popular, informal name for electronic products nearing the end of their “useful life.” Computers, televisions, VCRs, stereos, copiers, and fax machines are common electronic products. Many of these products can be reused, refurbished, or recycled. The hazardous and toxic substances found in e-waste include lead (Pb) and cadmium (Cd) in printed circuit boards (PCBs). Lead is primarily found in all electronic products/ assembly, cathode ray tubes (CRT) etc. Cadmium is found in monitor/ CRTs while there may be mercury in switches and flat screen monitors. E-waste is electronic products that are unwanted, not working, and nearing or at the end of their “useful life.” Computers, televisions, VCRs, stereos, copiers, and fax machines are everyday electronic products. The ongoing challenge of how best to dispose of used and unwanted electronics isn’t a new one and dates back at least to the 1970s. But a lot has changed since then, particularly the number of electronics being discarded today. We also have something else today: a term for this issue. After several terms got suggested, including “Digital rubbish,” a consensus formed around the simple word “e-waste.”</p>



<div class="row">
<div class="environment-project environment-project-medium">
<ul class="row">
<li class="col-md-12">
<div class="environment-project-medium-wrap">
<figure><img src="./renu-logo/Home Appliances.jpg" alt=""></figure>
<section>
<h5>Home Appliances</h5>

<li>Microwaves </li>
<li>Home Entertainment Devices</li>
<li>Electric cookers</li>
<li>Heaters</li>
<li>Fans </li>

</section>
</div>
</li>
</ul>
</div>
</div>




<div class="row">
<div class="environment-project environment-project-medium">
<ul class="row">
<li class="col-md-12">
<div class="environment-project-medium-wrap">
<figure><img src="./renu-logo/Communications and Information Technology Devices.jpg" alt=""></figure>
<section>
<h5>Communications and Information Technology Devices</h5>

<li>Cell phones</li>
<li>Smartphones</li>
<li>Desktop Computers</li>
<li>Computer Monitors</li>
<li>Laptops</li>
<li>Circuit boards</li>
<li>Hard Drives</li>
</section>
</div>
</li>
</ul>
</div>
</div>





<div class="row">
<div class="environment-project environment-project-medium">
<ul class="row">
<li class="col-md-12">
<div class="environment-project-medium-wrap">
<figure><img src="./renu-logo/Home Entertainment Devices.jpg" alt=""></figure>
<section>
<h5>Home Entertainment Devices</h5>

<li>DVDs</li>
<li>Blu Ray Players</li>
<li>Stereos</li>
<li>Televisions</li>
<li>Video Game Systems</li>
<li>Fax machines</li>
<li>Copiers</li>
<li>Printers</li>
</section>
</div>
</li>
</ul>
</div>
</div>



<div class="row">
<div class="environment-project environment-project-medium">
<ul class="row">
<li class="col-md-12">
<div class="environment-project-medium-wrap">
<figure><img src="./renu-logo/Electronic Utilities.jpg" alt=""></figure>
<section>
<h5>Electronic Utilities</h5>

<li>Massage Chairs</li>
<li>Heating Pads</li>
<li>Remote Controls</li>
<li>Television Remotes</li>
<li>Electrical Cords</li>
<li>Lamps</li>
<li>Smart Lights</li>
<li>Night Lights</li>
<li>Treadmills</li>
<li>FitBits</li>
<li>Smart Watches</li>
<li>Heart Monitors</li>
<li>Diabetic Testing Equipment</li>
</section>
</div>
</li>
</ul>
</div>
</div>





</div>

</div>
</div>
</div>

</div>




</div>
</div>


<?php 
include "include/footer.php";
?>